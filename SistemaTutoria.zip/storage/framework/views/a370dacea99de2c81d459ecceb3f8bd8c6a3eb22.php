<?php $__env->startSection('menu'); ?>
<!-- Seccion por si se debe agregar un penu personal -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<h1 class="mt-4">Panel de subir Mobiliario </h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active"></li>
</ol>

<form action="<?php echo e(route('update.salon')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Import</button>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>