<!DOCTYPE html>
<html>
<head>
    <title>Registros</title>
</head>
<body>
    <h1>Registros</h1>
    <table border="1">
        <tr>
            <th>Región Militar</th>
            <th>Zona Militar</th>
            <th>Fecha</th>
            <th>Conteo de Correos</th>
        </tr>
        <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($registro['region_militar']); ?></td>
                <td><?php echo e($registro['zona_militar']); ?></td>
                <td><?php echo e($registro['fecha']); ?></td>
                <td><?php echo e($registro['count']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
