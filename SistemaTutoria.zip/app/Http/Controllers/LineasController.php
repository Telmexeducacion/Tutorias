<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LineasController extends Controller
{

}
