<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estatuslinea extends Model
{
    //
     // Nombre de la tabla en la base de datos
     protected $table = 'estatuslineas';

     // Campos que pueden ser asignados de forma masiva
     protected $fillable = [
         'estatus',
         'detalle'
     ];


}
